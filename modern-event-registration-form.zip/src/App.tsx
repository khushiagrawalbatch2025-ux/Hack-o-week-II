import { useState, useEffect } from 'react';
import { cn } from './utils/cn';

interface FormData {
  fullName: string;
  email: string;
  phone: string;
  college: string;
  department: string;
  year: string;
  event: string;
  teamSize: string;
  dietaryRestrictions: string;
  agreeToTerms: boolean;
}

const events = [
  { id: 'hackathon', name: 'HACKATHON', subtitle: '48HR CODE', date: 'MAR 15-17', spots: 50, icon: '⚡' },
  { id: 'workshop', name: 'AI/ML', subtitle: 'WORKSHOP', date: 'MAR 20', spots: 30, icon: '🤖' },
  { id: 'cultural', name: 'CULTURAL', subtitle: 'FEST', date: 'MAR 25-27', spots: 200, icon: '🎭' },
  { id: 'sports', name: 'SPORTS', subtitle: 'MEET', date: 'APR 1-3', spots: 100, icon: '🏆' },
  { id: 'techtalks', name: 'TECH', subtitle: 'TALKS', date: 'APR 10', spots: 80, icon: '🎤' },
];

const years = ['1ST YEAR', '2ND YEAR', '3RD YEAR', '4TH YEAR', 'POST GRAD'];
const teamSizes = ['SOLO', 'DUO', 'TRIO', 'SQUAD (4)', 'TEAM (5+)'];

export function App() {
  const [formData, setFormData] = useState<FormData>({
    fullName: '',
    email: '',
    phone: '',
    college: '',
    department: '',
    year: '',
    event: '',
    teamSize: '',
    dietaryRestrictions: '',
    agreeToTerms: false,
  });

  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({});
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [, setCurrentSection] = useState(0);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const validateForm = () => {
    const newErrors: Partial<Record<keyof FormData, string>> = {};
    
    if (!formData.fullName.trim()) newErrors.fullName = 'REQUIRED';
    if (!formData.email.trim()) {
      newErrors.email = 'REQUIRED';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'INVALID';
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'REQUIRED';
    } else if (!/^\d{10}$/.test(formData.phone.replace(/\D/g, ''))) {
      newErrors.phone = 'INVALID';
    }
    if (!formData.college.trim()) newErrors.college = 'REQUIRED';
    if (!formData.department.trim()) newErrors.department = 'REQUIRED';
    if (!formData.year) newErrors.year = 'SELECT';
    if (!formData.event) newErrors.event = 'SELECT';
    if (!formData.teamSize) newErrors.teamSize = 'SELECT';
    if (!formData.agreeToTerms) newErrors.agreeToTerms = 'ACCEPT TERMS';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      setSubmitted(true);
    }
  };

  const handleChange = (field: keyof FormData, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  if (submitted) {
    return (
      <div className="noise-overlay min-h-screen bg-black flex items-center justify-center p-4 relative overflow-hidden">
        {/* Gradient orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-green-500/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl" />
        
        <div className="relative z-10 text-center max-w-2xl mx-auto">
          <div className="float-effect mb-8">
            <div className="w-32 h-32 mx-auto border-2 border-green-400 rounded-full flex items-center justify-center glow-effect">
              <svg className="w-16 h-16 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </div>
          
          <h1 className="text-6xl md:text-8xl font-black text-white mb-4 tracking-tighter">
            YOU'RE <span className="text-green-400">IN</span>
          </h1>
          
          <div className="h-px w-32 bg-gradient-to-r from-transparent via-green-400 to-transparent mx-auto my-8" />
          
          <p className="text-xl md:text-2xl text-neutral-400 mb-2 uppercase tracking-widest">
            Welcome, <span className="text-white font-bold">{formData.fullName}</span>
          </p>
          
          <p className="text-lg text-neutral-500 mb-8 uppercase tracking-wider">
            Registered for <span className="text-green-400 font-bold">
              {events.find(e => e.id === formData.event)?.name}
            </span>
          </p>
          
          <div className="inline-block border border-neutral-800 rounded-lg p-6 mb-10 bg-neutral-900/50 backdrop-blur">
            <p className="text-neutral-500 text-sm uppercase tracking-widest mb-2">Confirmation sent to</p>
            <p className="text-white font-mono">{formData.email}</p>
          </div>
          
          <button
            onClick={() => {
              setSubmitted(false);
              setFormData({
                fullName: '',
                email: '',
                phone: '',
                college: '',
                department: '',
                year: '',
                event: '',
                teamSize: '',
                dietaryRestrictions: '',
                agreeToTerms: false,
              });
              setCurrentSection(0);
            }}
            className="group relative px-10 py-5 bg-transparent border-2 border-green-400 text-green-400 font-bold uppercase tracking-widest overflow-hidden transition-all duration-300 hover:text-black"
          >
            <span className="relative z-10">REGISTER ANOTHER</span>
            <div className="absolute inset-0 bg-green-400 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="noise-overlay min-h-screen bg-black text-white relative overflow-hidden">
      {/* Cursor follower */}
      <div 
        className="fixed w-96 h-96 bg-green-500/5 rounded-full blur-3xl pointer-events-none transition-all duration-1000 ease-out"
        style={{
          left: mousePosition.x - 192,
          top: mousePosition.y - 192,
        }}
      />
      
      {/* Grid background */}
      <div className="fixed inset-0 opacity-[0.03]" style={{
        backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
        backgroundSize: '60px 60px'
      }} />

      {/* Hero Section */}
      <header className="relative min-h-[60vh] flex items-center justify-center border-b border-neutral-900">
        <div className="absolute top-8 left-8 md:left-16 z-20">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 bg-green-400 rounded-full glow-effect" />
            <span className="text-xs uppercase tracking-[0.3em] text-neutral-500">Live Registration</span>
          </div>
        </div>
        
        <div className="absolute top-8 right-8 md:right-16 z-20">
          <span className="text-xs uppercase tracking-[0.3em] text-neutral-500 font-mono">2024</span>
        </div>
        
        <div className="text-center z-10 px-4">
          <p className="text-neutral-500 uppercase tracking-[0.5em] text-sm mb-6 md:mb-8">College Events</p>
          <h1 className="text-5xl md:text-8xl lg:text-[10rem] font-black tracking-tighter leading-none mb-4">
            REGISTER
          </h1>
          <div className="flex items-center justify-center gap-4 md:gap-8 text-neutral-500">
            <span className="text-xs md:text-sm uppercase tracking-widest">Select Event</span>
            <div className="w-16 md:w-32 h-px bg-gradient-to-r from-green-400 to-transparent" />
            <span className="text-xs md:text-sm uppercase tracking-widest">Fill Details</span>
            <div className="w-16 md:w-32 h-px bg-gradient-to-r from-green-400 to-transparent" />
            <span className="text-xs md:text-sm uppercase tracking-widest">Confirm</span>
          </div>
        </div>
        
        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
          <span className="text-xs uppercase tracking-widest text-neutral-600">Scroll</span>
          <div className="w-px h-16 bg-gradient-to-b from-green-400 to-transparent" />
        </div>
      </header>

      <form onSubmit={handleSubmit} className="relative z-10">
        {/* Event Selection Section */}
        <section className="min-h-screen border-b border-neutral-900 py-20 md:py-32 px-4 md:px-16">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center gap-4 mb-12 md:mb-20">
              <span className="text-green-400 font-mono text-sm">01</span>
              <div className="w-16 h-px bg-green-400" />
              <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tight">Choose Your Event</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
              {events.map((event, index) => (
                <button
                  type="button"
                  key={event.id}
                  onClick={() => {
                    handleChange('event', event.id);
                    setCurrentSection(1);
                  }}
                  className={cn(
                    "group relative p-6 md:p-8 text-left transition-all duration-500 border overflow-hidden",
                    formData.event === event.id
                      ? "border-green-400 bg-green-400/5"
                      : "border-neutral-800 hover:border-neutral-600 bg-neutral-900/50"
                  )}
                >
                  {/* Background number */}
                  <span className="absolute -right-4 -bottom-8 text-[8rem] md:text-[12rem] font-black text-neutral-900 group-hover:text-neutral-800 transition-colors duration-500 select-none">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                  
                  <div className="relative z-10">
                    <span className="text-3xl md:text-4xl mb-4 block">{event.icon}</span>
                    <h3 className="text-2xl md:text-4xl font-black tracking-tight mb-1">{event.name}</h3>
                    <p className="text-lg md:text-xl text-neutral-500 font-light mb-4">{event.subtitle}</p>
                    
                    <div className="flex items-center justify-between pt-4 border-t border-neutral-800">
                      <span className="text-xs md:text-sm text-neutral-400 uppercase tracking-widest">{event.date}</span>
                      <span className={cn(
                        "text-xs md:text-sm font-mono",
                        event.spots < 50 ? "text-orange-400" : "text-green-400"
                      )}>
                        {event.spots} SPOTS
                      </span>
                    </div>
                  </div>
                  
                  {formData.event === event.id && (
                    <div className="absolute top-4 right-4 w-6 h-6 bg-green-400 flex items-center justify-center">
                      <svg className="w-4 h-4 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  )}
                </button>
              ))}
            </div>
            {errors.event && (
              <p className="text-red-500 text-sm mt-4 uppercase tracking-widest">{errors.event}</p>
            )}
          </div>
        </section>

        {/* Personal Info Section */}
        <section className="min-h-screen border-b border-neutral-900 py-20 md:py-32 px-4 md:px-16">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-4 mb-12 md:mb-20">
              <span className="text-green-400 font-mono text-sm">02</span>
              <div className="w-16 h-px bg-green-400" />
              <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tight">Your Details</h2>
            </div>
            
            <div className="space-y-8 md:space-y-12">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
                <InputField
                  label="FULL NAME"
                  placeholder="ENTER YOUR NAME"
                  value={formData.fullName}
                  onChange={(v) => handleChange('fullName', v)}
                  error={errors.fullName}
                />
                <InputField
                  label="EMAIL"
                  type="email"
                  placeholder="YOUR@EMAIL.COM"
                  value={formData.email}
                  onChange={(v) => handleChange('email', v)}
                  error={errors.email}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
                <InputField
                  label="PHONE"
                  type="tel"
                  placeholder="1234567890"
                  value={formData.phone}
                  onChange={(v) => handleChange('phone', v)}
                  error={errors.phone}
                />
                <InputField
                  label="COLLEGE"
                  placeholder="YOUR INSTITUTION"
                  value={formData.college}
                  onChange={(v) => handleChange('college', v)}
                  error={errors.college}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
                <InputField
                  label="DEPARTMENT"
                  placeholder="YOUR FIELD"
                  value={formData.department}
                  onChange={(v) => handleChange('department', v)}
                  error={errors.department}
                />
                <SelectField
                  label="YEAR"
                  placeholder="SELECT YEAR"
                  options={years}
                  value={formData.year}
                  onChange={(v) => handleChange('year', v)}
                  error={errors.year}
                />
              </div>
            </div>
          </div>
        </section>

        {/* Event Details Section */}
        <section className="min-h-[70vh] border-b border-neutral-900 py-20 md:py-32 px-4 md:px-16">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-4 mb-12 md:mb-20">
              <span className="text-green-400 font-mono text-sm">03</span>
              <div className="w-16 h-px bg-green-400" />
              <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tight">Team Config</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
              <div>
                <label className="block text-xs uppercase tracking-[0.3em] text-neutral-500 mb-4">
                  Team Size
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {teamSizes.map((size) => (
                    <button
                      key={size}
                      type="button"
                      onClick={() => handleChange('teamSize', size)}
                      className={cn(
                        "p-3 md:p-4 border text-xs md:text-sm uppercase tracking-wider transition-all duration-300",
                        formData.teamSize === size
                          ? "border-green-400 bg-green-400/10 text-green-400"
                          : "border-neutral-800 text-neutral-400 hover:border-neutral-600"
                      )}
                    >
                      {size}
                    </button>
                  ))}
                </div>
                {errors.teamSize && (
                  <p className="text-red-500 text-xs mt-2 uppercase tracking-widest">{errors.teamSize}</p>
                )}
              </div>
              
              <InputField
                label="DIETARY RESTRICTIONS"
                placeholder="NONE / VEG / VEGAN"
                value={formData.dietaryRestrictions}
                onChange={(v) => handleChange('dietaryRestrictions', v)}
              />
            </div>
          </div>
        </section>

        {/* Submit Section */}
        <section className="min-h-[80vh] flex items-center justify-center py-20 md:py-32 px-4 md:px-16 relative">
          {/* Background text */}
          <div className="absolute inset-0 flex items-center justify-center overflow-hidden pointer-events-none">
            <span className="text-[15vw] font-black text-neutral-900/50 uppercase tracking-tighter select-none">
              SUBMIT
            </span>
          </div>
          
          <div className="max-w-2xl mx-auto text-center relative z-10">
            <div className="flex items-center justify-center gap-4 mb-12">
              <span className="text-green-400 font-mono text-sm">04</span>
              <div className="w-16 h-px bg-green-400" />
              <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tight">Confirm</h2>
              <div className="w-16 h-px bg-green-400" />
            </div>
            
            {/* Terms checkbox */}
            <div className="mb-12">
              <label className="flex items-center justify-center gap-4 cursor-pointer group">
                <div 
                  onClick={() => handleChange('agreeToTerms', !formData.agreeToTerms)}
                  className={cn(
                    "w-6 h-6 border-2 flex items-center justify-center transition-all duration-300",
                    formData.agreeToTerms
                      ? "border-green-400 bg-green-400"
                      : "border-neutral-600 group-hover:border-neutral-400"
                  )}
                >
                  {formData.agreeToTerms && (
                    <svg className="w-4 h-4 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </div>
                <span className="text-sm text-neutral-400 uppercase tracking-wider">
                  I accept the <span className="text-green-400 hover:underline cursor-pointer">terms</span> & <span className="text-green-400 hover:underline cursor-pointer">privacy policy</span>
                </span>
              </label>
              {errors.agreeToTerms && (
                <p className="text-red-500 text-xs mt-4 uppercase tracking-widest">{errors.agreeToTerms}</p>
              )}
            </div>
            
            <button
              type="submit"
              className="group relative w-full md:w-auto px-16 md:px-24 py-6 md:py-8 bg-green-400 text-black font-black text-xl md:text-2xl uppercase tracking-wider overflow-hidden transition-all duration-300 hover:scale-105 active:scale-95"
            >
              <span className="relative z-10">REGISTER NOW</span>
              <div className="absolute inset-0 bg-white transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
              <span className="absolute inset-0 flex items-center justify-center font-black text-xl md:text-2xl uppercase tracking-wider text-black opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-200">
                LET'S GO →
              </span>
            </button>
            
            <p className="text-neutral-600 text-xs uppercase tracking-widest mt-8">
              You'll receive a confirmation email after registration
            </p>
          </div>
        </section>
      </form>

      {/* Footer */}
      <footer className="border-t border-neutral-900 py-12 px-4 md:px-16">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 bg-green-400 rounded-full" />
            <span className="text-xs uppercase tracking-[0.3em] text-neutral-600">College Events 2024</span>
          </div>
          <div className="flex items-center gap-8">
            <a href="#" className="text-xs uppercase tracking-widest text-neutral-500 hover:text-green-400 transition-colors">Contact</a>
            <a href="#" className="text-xs uppercase tracking-widest text-neutral-500 hover:text-green-400 transition-colors">FAQ</a>
            <a href="#" className="text-xs uppercase tracking-widest text-neutral-500 hover:text-green-400 transition-colors">Terms</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

// Input Field Component - LandoNorris style
function InputField({
  label,
  type = 'text',
  placeholder,
  value,
  onChange,
  error,
}: {
  label: string;
  type?: string;
  placeholder: string;
  value: string;
  onChange: (value: string) => void;
  error?: string;
}) {
  const [focused, setFocused] = useState(false);
  
  return (
    <div className="relative">
      <label className="block text-xs uppercase tracking-[0.3em] text-neutral-500 mb-3">
        {label}
        {error && <span className="text-red-500 ml-2">— {error}</span>}
      </label>
      <div className="relative">
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          className={cn(
            "w-full bg-transparent border-b-2 py-4 text-lg md:text-xl font-light tracking-wide placeholder:text-neutral-700 focus:outline-none transition-all duration-300",
            error
              ? "border-red-500 text-red-400"
              : focused
                ? "border-green-400 text-white"
                : "border-neutral-800 text-white hover:border-neutral-600"
          )}
        />
        <div className={cn(
          "absolute bottom-0 left-0 h-0.5 bg-green-400 transition-all duration-500",
          focused ? "w-full" : "w-0"
        )} />
      </div>
    </div>
  );
}

// Select Field Component - LandoNorris style
function SelectField({
  label,
  placeholder,
  options,
  value,
  onChange,
  error,
}: {
  label: string;
  placeholder: string;
  options: string[];
  value: string;
  onChange: (value: string) => void;
  error?: string;
}) {
  const [open, setOpen] = useState(false);
  
  return (
    <div className="relative">
      <label className="block text-xs uppercase tracking-[0.3em] text-neutral-500 mb-3">
        {label}
        {error && <span className="text-red-500 ml-2">— {error}</span>}
      </label>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className={cn(
          "w-full bg-transparent border-b-2 py-4 text-lg md:text-xl font-light tracking-wide text-left focus:outline-none transition-all duration-300 flex items-center justify-between",
          error
            ? "border-red-500"
            : value
              ? "border-green-400"
              : "border-neutral-800 hover:border-neutral-600"
        )}
      >
        <span className={value ? "text-white" : "text-neutral-700"}>
          {value || placeholder}
        </span>
        <svg 
          className={cn(
            "w-5 h-5 text-neutral-500 transition-transform duration-300",
            open && "rotate-180"
          )} 
          fill="none" 
          stroke="currentColor" 
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      
      {open && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-neutral-900 border border-neutral-800 z-50">
          {options.map((option) => (
            <button
              key={option}
              type="button"
              onClick={() => {
                onChange(option);
                setOpen(false);
              }}
              className={cn(
                "w-full px-4 py-3 text-left text-sm uppercase tracking-wider transition-all duration-200",
                value === option
                  ? "bg-green-400/10 text-green-400"
                  : "text-neutral-400 hover:bg-neutral-800 hover:text-white"
              )}
            >
              {option}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
